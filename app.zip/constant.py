"""Constants to be used throughout the application that are immutable"""

WEEKDAY = 'weekday'
SATURDAY = 'sat'
SUNDAY = 'sun'
SCHEDULE = 'schedule'

OUTPUT_STRING = 'Next bus from Beacon is at '
